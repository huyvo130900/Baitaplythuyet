package com.example.lab6;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.util.Random;

public class MessageActivity extends AppCompatActivity {

    private ProgressBar pbFirst, pbSecond;
    private TextView tvMsgWorking, tvMsgReturned;
    private boolean isRunning;
    private int MAX_SEC = 100;
    private int intTest;
    private Thread bgThread;
    private Handler handler;
    private Button btnStart;

    private static final int MSG_UPDATE = 1;
    private static final int MSG_STOPPED = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        findViewByIds();
        initVariables();
        setupHandler();

        btnStart.setOnClickListener(v -> {
            if (!isRunning) {
                isRunning = true;
                tvMsgWorking.setText(getString(R.string.working));
                initBgThread();
            }
        });
    }

    private void findViewByIds() {
        pbFirst = findViewById(R.id.pb_first);
        pbSecond = findViewById(R.id.pb_second);
        tvMsgWorking = findViewById(R.id.tv_working);
        tvMsgReturned = findViewById(R.id.tv_return);
        btnStart = findViewById(R.id.btn_start);
    }

    private void initVariables() {
        isRunning = false;
        intTest = 0;
        pbFirst.setMax(MAX_SEC);
        pbSecond.setIndeterminate(false);
    }

    private void setupHandler() {
        handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == MSG_UPDATE) {
                    int randomValue = (Integer) msg.obj;
                    intTest++;
                    pbFirst.setProgress(Math.min(intTest, pbFirst.getMax()));
                    tvMsgReturned.setText(getString(R.string.returned_by_bg_thread)
                            + "Random: " + randomValue
                            + getString(R.string.global_value_seen) + ": " + intTest);
                } else if (msg.what == MSG_STOPPED) {
                    tvMsgWorking.setText(getString(R.string.done_background_thread_has_been_stopped));
                    isRunning = false;
                }
            }
        };
    }

    private void initBgThread() {
        bgThread = new Thread(() -> {
            Random rnd = new Random();
            while (isRunning && intTest < MAX_SEC) {
                int value = rnd.nextInt(101);
                Message m = handler.obtainMessage(MSG_UPDATE, value);
                handler.sendMessage(m);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    break;
                }
            }
            handler.sendEmptyMessage(MSG_STOPPED);
        });
        bgThread.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        isRunning = false;
        if (bgThread != null && bgThread.isAlive()) bgThread.interrupt();
    }
}
