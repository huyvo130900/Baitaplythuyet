package com.example.lab6;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PostActivity extends AppCompatActivity {

    private ProgressBar pbWaiting;
    private TextView tvTopCaption;
    private EditText etInput;
    private Button btnExecute, btnStop;

    private int globalValue, accum;
    private long startTime;
    private final String PATIENCE = "Some important data is being collected now.\nPlease be patient...wait...";
    private Handler handler;
    private Runnable fgRunnable, bgRunnable;
    private Thread testThread;
    private boolean isRunning = false; // Thêm biến kiểm soát luồng

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        findViewByIds();
        initVariables();

        // Khi nhấn Execute
        btnExecute.setOnClickListener(v -> {
            String text = etInput.getText().toString();
            Toast.makeText(PostActivity.this, text, Toast.LENGTH_SHORT).show();

            if (!isRunning) {
                isRunning = true;
                testThread = new Thread(bgRunnable);
                testThread.start();
            }
        });

        // Khi nhấn Stop
        btnStop.setOnClickListener(v -> {
            if (isRunning) {
                isRunning = false;
                Toast.makeText(PostActivity.this, "Background work stopped!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void findViewByIds() {
        tvTopCaption = findViewById(R.id.tv_top_caption);
        pbWaiting = findViewById(R.id.pb_waiting);
        etInput = findViewById(R.id.et_input);
        btnExecute = findViewById(R.id.btn_execute);

        // 🔹 Thêm nút Stop mới
        btnStop = new Button(this);
        btnStop.setText("STOP");
        ((android.widget.LinearLayout) pbWaiting.getParent()).addView(btnStop);
    }

    private void initVariables() {
        globalValue = 0;
        accum = 0;
        startTime = System.currentTimeMillis();
        handler = new Handler();

        fgRunnable = () -> {
            tvTopCaption.setText("Global value: " + globalValue + "  " + PATIENCE);
            pbWaiting.setProgress(globalValue % 100);
        };

        bgRunnable = () -> {
            while (isRunning) {
                globalValue++;
                handler.post(fgRunnable);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            // Khi dừng thread
            handler.post(() -> tvTopCaption.setText("Background work is over!"));
        };
    }

    @Override
    protected void onStop() {
        super.onStop();
        isRunning = false; // Dừng thread khi thoát activity
    }
}
