package com.example.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnLab1, btnLab2, btnLab3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        btnLab1 = findViewById(R.id.btn_lab1);
        btnLab2 = findViewById(R.id.btn_lab2);
        btnLab3 = findViewById(R.id.btn_lab3);

        btnLab1.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, MessageActivity.class)));

        btnLab2.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, PostActivity.class)));

        btnLab3.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AsyncActivity.class)));
    }
}
