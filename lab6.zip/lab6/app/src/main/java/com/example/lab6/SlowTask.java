package com.example.lab6;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

public class SlowTask extends AsyncTask<Void, Integer, Void> {

    private Context context;
    private TextView tvStatus;
    private ProgressDialog progressDialog;

    public SlowTask(Context context, TextView tvStatus) {
        this.context = context;
        this.tvStatus = tvStatus;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage(context.getString(R.string.please_wait));
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    @Override
    protected Void doInBackground(Void... voids) {
        for (int i = 1; i <= 5; i++) {
            if (isCancelled()) break;
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                break;
            }
            publishProgress(i);
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        tvStatus.setText("Progress: " + values[0]);
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        if (progressDialog != null && progressDialog.isShowing()) progressDialog.dismiss();
        tvStatus.setText("Done");
    }
}
