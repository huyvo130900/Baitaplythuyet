package com.example.lab7.downloadmanager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NotificationReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // Gửi Intent đến Service để xử lý
        Intent serviceIntent = new Intent(context, DownloadService.class);
        serviceIntent.setAction(intent.getAction());
        context.startService(serviceIntent);
    }
}