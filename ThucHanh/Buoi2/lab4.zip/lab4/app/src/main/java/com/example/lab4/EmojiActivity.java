package com.example.lab4;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class EmojiActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emoji);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new EmojiFragment())
                    .commit();
        }
    }
}