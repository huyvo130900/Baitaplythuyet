package com.example.lab4;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import java.util.Random;

public class EmojiFragment extends Fragment implements View.OnClickListener {

    private final int[] emojiIds = {
            R.id.iv1, R.id.iv2, R.id.iv3,
            R.id.iv4, R.id.iv5, R.id.iv6,
            R.id.iv7, R.id.iv8, R.id.iv9
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_emoji, container, false);
        initViews(v);
        return v;
    }

    private void initViews(View v) {
        for (int id : emojiIds) {
            v.findViewById(id).setOnClickListener(this);
        }
        v.findViewById(R.id.btn_random).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        ImageView iv;
        if (v.getId() == R.id.btn_random) {
            Random r = new Random();
            int idx = r.nextInt(emojiIds.length);
            iv = getView().findViewById(emojiIds[idx]);
        } else {
            iv = (ImageView) v;
        }
        showToast(iv.getDrawable());
    }

    private void showToast(Drawable d) {
        Toast toast = new Toast(requireContext());
        ImageView iv = new ImageView(requireContext());
        iv.setImageDrawable(d);
        toast.setView(iv);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
    }
}