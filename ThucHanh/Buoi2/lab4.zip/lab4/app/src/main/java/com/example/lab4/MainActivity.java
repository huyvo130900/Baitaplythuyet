package com.example.lab4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.example.lab4.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnBai1 = findViewById(R.id.btn_bai1);
        Button btnBai2 = findViewById(R.id.btn_bai2);
        Button btnBai3 = findViewById(R.id.btn_bai3);

        btnBai1.setOnClickListener(v -> startActivity(new Intent(this, com.example.lab4.LoginActivity.class)));
        btnBai2.setOnClickListener(v -> startActivity(new Intent(this, EnglishMenuActivity.class)));
        btnBai3.setOnClickListener(v -> startActivity(new Intent(this, EmojiActivity.class)));
    }
}