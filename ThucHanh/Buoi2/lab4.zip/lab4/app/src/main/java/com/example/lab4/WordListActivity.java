package com.example.lab4;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class WordListActivity extends AppCompatActivity {

    private final String[] words = {
            "hello", "world", "java", "android", "kotlin",
            "layout", "fragment", "activity", "toast", "view"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word_list);

        String topic = getIntent().getStringExtra("TOPIC");
        setupActionBar(topic);
        setupListView();
    }

    private void setupActionBar(String topic) {
        TextView tvTitle = findViewById(R.id.tv_title);
        tvTitle.setText(topic);

        findViewById(R.id.iv_back).setOnClickListener(v -> finish());
    }

    private void setupListView() {
        ListView lv = findViewById(R.id.lv_words);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                R.layout.item_word,
                R.id.tv_word,
                words
        ) {
            @Override
            public android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                android.view.View view = super.getView(position, convertView, parent);
                ImageView ivIcon = view.findViewById(R.id.iv_icon);
                ivIcon.setImageResource(R.drawable.ic_word);
                return view;
            }
        };
        lv.setAdapter(adapter);

        lv.setOnItemClickListener((parent, view, position, id) -> {
            String word = words[position];
            Toast.makeText(this, "Từ: " + word, Toast.LENGTH_SHORT).show();
        });
    }
}