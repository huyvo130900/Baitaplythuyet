package com.example.lab4;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class EnglishMenuActivity extends AppCompatActivity {

    private static final int[] DRAWABLES = {
            R.drawable.ic_mess, R.drawable.ic_flight, R.drawable.ic_hospital,
            R.drawable.ic_hotel, R.drawable.ic_restaurant, R.drawable.ic_coctail,
            R.drawable.ic_store, R.drawable.ic_at_work, R.drawable.ic_time,
            R.drawable.ic_education, R.drawable.ic_movie
    };

    private static final int[] TEXTS = {
            R.string.txt_mess, R.string.txt_flight, R.string.txt_hospital,
            R.string.txt_hotel, R.string.txt_restaurant, R.string.txt_coctail,
            R.string.txt_store, R.string.txt_work, R.string.txt_time,
            R.string.txt_education, R.string.txt_movie
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english_menu);

        findViewById(R.id.iv_back).setOnClickListener(v -> finish());

        initTopics();
    }

    private void initTopics() {
        LinearLayout container = findViewById(R.id.ln_topics);
        container.removeAllViews();

        for (int i = 0; i < DRAWABLES.length; i++) {
            View item = LayoutInflater.from(this).inflate(R.layout.item_topic, null);
            ImageView iv = item.findViewById(R.id.iv_icon);
            TextView tv = item.findViewById(R.id.tv_title);

            iv.setImageResource(DRAWABLES[i]);
            tv.setText(TEXTS[i]);

            // THÊM DÒNG NÀY: Click để chuyển sang WordList
            final String topic = getString(TEXTS[i]);
            item.setOnClickListener(v -> {
                Intent intent = new Intent(this, WordListActivity.class);
                intent.putExtra("TOPIC", topic);
                startActivity(intent);
            });

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 100
            );
            item.setLayoutParams(params);
            container.addView(item);
        }
    }
}