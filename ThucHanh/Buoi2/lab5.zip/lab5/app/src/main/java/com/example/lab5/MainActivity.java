package com.example.lab5;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnEx1 = findViewById(R.id.btn_ex1);
        Button btnEx2 = findViewById(R.id.btn_ex2);
        Button btnBonus = findViewById(R.id.btn_bonus);

        btnEx1.setOnClickListener(v -> startActivity(new Intent(this, AnimationActivity.class)));
        //.setOnClickListener(v -> startActivity(new Intent(this, QuickCallActivity.class)));
        //btnBonus.setOnClickListener(v -> startActivity(new Intent(this, BonusActivity.class)));
    }
}