package com.example.lab3; // Thay bằng tên package của bạn

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import android.content.pm.ActivityInfo;
import androidx.appcompat.widget.SwitchCompat;

public class M001TopicFrg extends Fragment {

    private ArrayList<TopicEntity> listTopic = new ArrayList<>();
    private RecyclerView rvTopic;
    private TopicAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m001_frg_topic, container, false);
        initViews(view);
        return view;
    }

    private void initViews(View view) {
        rvTopic = view.findViewById(R.id.rv_topic);

        // Tạo dữ liệu giả (mock data)
        listTopic.add(new TopicEntity("Con gái", "ic_congai"));
        listTopic.add(new TopicEntity("Công sở", "bg_categories")); // Bạn thay bằng tên ảnh đúng sau nhé
        listTopic.add(new TopicEntity("Cười 18", "bg_categories"));
        listTopic.add(new TopicEntity("Cực hài", "bg_categories"));
        listTopic.add(new TopicEntity("Dân gian", "bg_categories"));
        listTopic.add(new TopicEntity("Gia đình", "bg_categories"));
        listTopic.add(new TopicEntity("Giao thông", "bg_categories"));
        listTopic.add(new TopicEntity("Học sinh", "bg_categories"));

        // Khởi tạo Adapter
        adapter = new TopicAdapter(listTopic, getContext());

        // Cài đặt cho RecyclerView
        rvTopic.setLayoutManager(new LinearLayoutManager(getContext()));
        rvTopic.setAdapter(adapter);

        // --- BẮT ĐẦU CODE BÀI TẬP 1 (ĐÃ SỬA LỖI) ---

        // 1. Ánh xạ Switch từ layout
        SwitchCompat swRotate = view.findViewById(R.id.sw_rotate);

        // 2. Đặt trạng thái ban đầu DỰA TRÊN TRẠNG THÁI CỦA SWITCH
        // (Phải làm điều này trước khi gán listener)
        if (getActivity() != null) {
            if (swRotate.isChecked()) {
                // Switch đang "On" (từ XML), cho phép xoay
                getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
            } else {
                // Switch đang "Off", khóa dọc
                getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        }

        // 3. Gán listener (chỉ chạy KHI NGƯỜI DÙNG BẤM)
        swRotate.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (getActivity() == null) return; // Đảm bảo Activity còn tồn tại

            if (isChecked) {
                // Người dùng gạt "On" -> Cho phép xoay
                getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
            } else {
                // Người dùng gạt "Off" -> Khóa Dọc
                getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        });

        // --- KẾT THÚC CODE BÀI TẬP 1 ---
    }
}