package com.example.lab3; // Thay bằng tên package của bạn

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;
import java.util.ArrayList;

public class M003StoryDetailFrg extends Fragment {

    private ViewPager2 vpStoryContent;
    private StoryDetailAdapter adapter;
    private ArrayList<StoryEntity> listStory;
    private String topicName;
    private int clickedPosition; // Vị trí truyện được click

    // Constructor để nhận dữ liệu
    public M003StoryDetailFrg(String topicName, ArrayList<StoryEntity> listStory, int clickedPosition) {
        this.topicName = topicName;
        this.listStory = listStory;
        this.clickedPosition = clickedPosition;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m003_frg_story_detail, container, false);
        initViews(view);
        return view;
    }

    private void initViews(View view) {
        // Ánh xạ View
        vpStoryContent = view.findViewById(R.id.vp_story_content);
        TextView tvTopicTitle = view.findViewById(R.id.tv_topic_title_detail);
        ImageView ivBack = view.findViewById(R.id.iv_back_story_list);

        // Gán tiêu đề
        tvTopicTitle.setText(topicName);

        // Khởi tạo Adapter
        adapter = new StoryDetailAdapter(listStory);

        // Cài đặt Adapter cho ViewPager2
        vpStoryContent.setAdapter(adapter);

        // **QUAN TRỌNG:** Di chuyển ViewPager2 đến đúng trang đã được click
        vpStoryContent.setCurrentItem(clickedPosition, false);

        // Xử lý nút quay lại
        ivBack.setOnClickListener(v -> {
            // Gọi hàm quay lại Màn hình 3 (M002)
            ((TruyenCuoiActivity) getActivity()).gotoM002Screen(topicName);
        });
    }
}