package com.example.lab3; // Thay bằng tên package của bạn

public class TopicEntity {
    private String topicName;
    private String topicImageName; // Tên file ảnh (ví dụ: "ic_congai")

    // Constructor
    public TopicEntity(String topicName, String topicImageName) {
        this.topicName = topicName;
        this.topicImageName = topicImageName;
    }

    // Getters
    public String getTopicName() {
        return topicName;
    }

    public String getTopicImageName() {
        return topicImageName;
    }
}