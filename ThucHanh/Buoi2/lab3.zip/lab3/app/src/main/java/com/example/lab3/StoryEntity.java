package com.example.lab3; // Thay bằng tên package của bạn

public class StoryEntity {
    private String storyTitle;
    private String storyContent;

    // Constructor
    public StoryEntity(String storyTitle, String storyContent) {
        this.storyTitle = storyTitle;
        this.storyContent = storyContent;
    }

    // Getters
    public String getStoryTitle() {
        return storyTitle;
    }

    public String getStoryContent() {
        return storyContent;
    }
}