package com.example.lab3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

// Đây là file Menu (sử dụng layout activity_main.xml có 2 nút)
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Layout có 2 nút

        // Ánh xạ 2 nút
        Button btnBai1 = findViewById(R.id.btn_bai_1);
        Button btnBai2 = findViewById(R.id.btn_bai_2);

        // Xử lý sự kiện bấm nút Bài 1
        btnBai1.setOnClickListener(v -> {
            // Mở Activity của Bài 1 (TruyenCuoiActivity)
            Intent intent = new Intent(MainActivity.this, TruyenCuoiActivity.class);
            startActivity(intent);
        });

        btnBai2.setOnClickListener(v -> {
            // Mở Activity của Bài 2 (LoginBai2Activity)
            Intent intent = new Intent(MainActivity.this, LoginBai2Activity.class);
            startActivity(intent);
        });
    }
}