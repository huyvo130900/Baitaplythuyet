package com.example.lab3; // Thay bằng tên package của bạn

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class M002StoryListFrg extends Fragment {

    public String topicName;
    private ArrayList<StoryEntity> listStory = new ArrayList<>();
    private RecyclerView rvStory;
    private StoryAdapter adapter;
    // Constructor để nhận tên chủ đề
    public M002StoryListFrg(String topicName) {
        this.topicName = topicName;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m002_frg_story_list, container, false);
        initViews(view);
        return view;
    }

    private void initViews(View view) {
        // Ánh xạ View
        rvStory = view.findViewById(R.id.rv_story);
        TextView tvTopicTitle = view.findViewById(R.id.tv_topic_title);
        ImageView ivBack = view.findViewById(R.id.iv_back_topic);

        // Gán tên chủ đề cho thanh tiêu đề
        tvTopicTitle.setText(topicName);

        // --- BẮT ĐẦU SỬA NỘI DUNG ---
        // Tạo dữ liệu giả (mock data) cho truyện
        String viecHocContent = "Lúc bé, nghĩ học là chuyện lạ. Lớn lên mới biết, chuyện lạ là đi học.\n\n" +
                "Lúc bé, tưởng đến trường là phải học. Lớn lên mới biết, đến trường còn được ngủ.\n\n" +
                "Lúc bé, tưởng thi xong là hết. Lớn lên mai biết, sau thì còn cô thì lạ.\n\n" +
                "Lúc bé, tưởng điểm 10 mới là giỏi. Lớn lên mới biết, chỉ 5 thôi đã quý lắm rồi.\n\n";

        listStory.add(new StoryEntity("Việc học", viecHocContent));
        // --- KẾT THÚC SỬA NỘI DUNG ---

        listStory.add(new StoryEntity("Đã hai lần rồi", "Nội dung truyện..."));
        listStory.add(new StoryEntity("Cũng như nhau", "Nội dung truyện..."));
        listStory.add(new StoryEntity("Rất lạnh", "Nội dung truyện..."));
        listStory.add(new StoryEntity("Im lặng là vàng", "Nội dung truyện..."));
        listStory.add(new StoryEntity("Bài học về tội nói dối", "Nội dung truyện..."));
        // (Bạn có thể thêm các truyện khác)

        // Khởi tạo Adapter
        adapter = new StoryAdapter(listStory, getContext());

        // Cài đặt cho RecyclerView
        rvStory.setLayoutManager(new LinearLayoutManager(getContext()));
        rvStory.setAdapter(adapter);

        // Xử lý nút quay lại
        ivBack.setOnClickListener(v -> {
            // Gọi hàm quay lại trong MainActivity
            ((TruyenCuoiActivity) getActivity()).backToM001Screen();
        });
    }
}