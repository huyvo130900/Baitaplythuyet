package com.example.lab3;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class LoginBai2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_bai2);

        // Ánh xạ các nút chọn ngôn ngữ
        TextView tvLangVi = findViewById(R.id.tv_lang_vi);
        TextView tvLangEn = findViewById(R.id.tv_lang_en);
        TextView tvLangFr = findViewById(R.id.tv_lang_fr);

        // Gán sự kiện click
        tvLangVi.setOnClickListener(v -> setLocale("vi"));
        tvLangEn.setOnClickListener(v -> setLocale("en"));
        tvLangFr.setOnClickListener(v -> setLocale("fr"));
    }

    /**
     * Hàm này đổi ngôn ngữ của ứng dụng và khởi động lại Activity
     * @param langCode Mã ngôn ngữ (ví dụ: "vi", "en", "fr")
     */
    private void setLocale(String langCode) {
        // Tạo đối tượng Locale mới
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);

        // Cập nhật configuration
        Resources res = getResources();
        Configuration config = res.getConfiguration();
        config.setLocale(locale);
        res.updateConfiguration(config, res.getDisplayMetrics());

        // Khởi động lại Activity này để áp dụng thay đổi
        // (Đây là cách đơn giản nhất)
        Intent intent = new Intent(this, LoginBai2Activity.class);
        startActivity(intent);
        finish(); // Đóng Activity cũ
    }
}