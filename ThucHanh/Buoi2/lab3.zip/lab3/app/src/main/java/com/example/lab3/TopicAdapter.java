package com.example.lab3; // Thay bằng tên package của bạn

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

// Adapter cần kế thừa (extends) RecyclerView.Adapter
// và chỉ định ViewHolder của nó (chúng ta sẽ tạo ở dưới)
public class TopicAdapter extends RecyclerView.Adapter<TopicAdapter.TopicViewHolder> {

    private ArrayList<TopicEntity> listTopic;
    private Context context;

    // Constructor để nhận dữ liệu và Context
    public TopicAdapter(ArrayList<TopicEntity> listTopic, Context context) {
        this.listTopic = listTopic;
        this.context = context;
    }

    // 1. Tạo ViewHolder:
    // Phương thức này gọi khi RecyclerView cần tạo 1 view mới (1 hàng)
    @NonNull
    @Override
    public TopicViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate (thổi phồng) file layout "item_topic.xml" của chúng ta
        View view = LayoutInflater.from(context).inflate(R.layout.item_topic, parent, false);
        return new TopicViewHolder(view);
    }

    // 2. Gán Dữ liệu vào ViewHolder:
    // Phương thức này gọi khi RecyclerView muốn hiển thị dữ liệu tại 1 vị trí (position)
    @Override
    public void onBindViewHolder(@NonNull TopicViewHolder holder, int position) {
        // Lấy topic tại vị trí "position"
        TopicEntity topic = listTopic.get(position);

        // Gán dữ liệu vào các view bên trong ViewHolder
        holder.tvTopicName.setText(topic.getTopicName());

        // Lấy ID của ảnh từ tên file (ví dụ: "ic_congai")
        int imageId = context.getResources().getIdentifier(
                topic.getTopicImageName(), "drawable", context.getPackageName());

        // Gán ảnh
        if (imageId != 0) { // Nếu tìm thấy ảnh
            holder.ivTopicImage.setImageResource(imageId);
        } else { // Nếu không, dùng ảnh mặc định
            holder.ivTopicImage.setImageResource(R.drawable.ic_launcher_background); // Ảnh mặc định
        }
    }

    // 3. Trả về số lượng item:
    // RecyclerView cần biết có bao nhiêu item để hiển thị
    @Override
    public int getItemCount() {
        return listTopic.size();
    }

    // ===== Lớp ViewHolder =====
    // Lớp này dùng để "giữ" các view của file "item_topic.xml"
    // (Giúp tăng tốc độ, không phải findViewById nhiều lần)
    public class TopicViewHolder extends RecyclerView.ViewHolder {
        ImageView ivTopicImage;
        TextView tvTopicName;

        public TopicViewHolder(@NonNull View itemView) {
            super(itemView);
            ivTopicImage = itemView.findViewById(R.id.iv_topic_image);
            tvTopicName = itemView.findViewById(R.id.tv_topic_name);

            // THÊM ĐOẠN CODE NÀY:
            // Xử lý khi người dùng bấm vào một item
            itemView.setOnClickListener(v -> {
                // Lấy vị trí của item được click
                int position = getAdapterPosition();

                // Lấy chủ đề tương ứng
                TopicEntity clickedTopic = listTopic.get(position);

                // Gọi hàm trong MainActivity để chuyển màn hình
                ((TruyenCuoiActivity) context).gotoM002Screen(clickedTopic.getTopicName());
            });
        }
    }
}