package com.example.lab3; // Thay bằng tên package của bạn

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

// ViewPager2 dùng RecyclerView.Adapter, nên cách viết y hệt
public class StoryDetailAdapter extends RecyclerView.Adapter<StoryDetailAdapter.StoryDetailViewHolder> {

    private ArrayList<StoryEntity> listStory;

    // Constructor chỉ cần nhận danh sách truyện
    public StoryDetailAdapter(ArrayList<StoryEntity> listStory) {
        this.listStory = listStory;
    }

    @NonNull
    @Override
    public StoryDetailViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate layout "item_story_content.xml"
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_story_content, parent, false);
        return new StoryDetailViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryDetailViewHolder holder, int position) {
        // Lấy truyện tại vị trí
        StoryEntity story = listStory.get(position);

        // Gán dữ liệu vào các View
        holder.tvStoryTitle.setText(story.getStoryTitle());
        holder.tvStoryContent.setText(story.getStoryContent());
    }

    @Override
    public int getItemCount() {
        return listStory.size();
    }

    // ViewHolder cho một trang truyện
    public class StoryDetailViewHolder extends RecyclerView.ViewHolder {
        TextView tvStoryTitle;
        TextView tvStoryContent;

        public StoryDetailViewHolder(@NonNull View itemView) {
            super(itemView);
            // Ánh xạ View
            tvStoryTitle = itemView.findViewById(R.id.tv_story_title_content);
            tvStoryContent = itemView.findViewById(R.id.tv_story_content);
        }
    }
}