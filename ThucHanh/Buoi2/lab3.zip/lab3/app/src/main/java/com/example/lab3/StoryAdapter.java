package com.example.lab3; // Thay bằng tên package của bạn

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.TreeMap;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.StoryViewHolder> {

    private ArrayList<StoryEntity> listStory;
    private Context context;

    public StoryAdapter(ArrayList<StoryEntity> listStory, Context context) {
        this.listStory = listStory;
        this.context = context;
    }

    @NonNull
    @Override
    public StoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate (thổi phồng) file layout "item_story.xml"
        View view = LayoutInflater.from(context).inflate(R.layout.item_story, parent, false);
        return new StoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryViewHolder holder, int position) {
        StoryEntity story = listStory.get(position);

        // Gán tên truyện
        holder.tvStoryTitle.setText(story.getStoryTitle());

        // (Code xử lý click vào 1 truyện sẽ thêm ở đây sau)
    }

    @Override
    public int getItemCount() {
        return listStory.size();
    }

    // Lớp ViewHolder để "giữ" các view của file "item_story.xml"
    // Lớp ViewHolder để "giữ" các view của file "item_story.xml"
    public class StoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvStoryTitle;

        public StoryViewHolder(@NonNull View itemView) {
            super(itemView);
            // Ánh xạ view
            tvStoryTitle = itemView.findViewById(R.id.tv_story_title);

            // THÊM ĐOẠN CODE NÀY:
            // Xử lý khi người dùng bấm vào 1 truyện
            itemView.setOnClickListener(v -> {
                // Lấy vị trí truyện được click
                int clickedPosition = getAdapterPosition();

                // Lấy tên chủ đề (từ Fragment M002)
                String topicName = ((M002StoryListFrg) ((MainActivity) context)
                        .getSupportFragmentManager()
                        .findFragmentById(R.id.ln_main))
                        .topicName; // Hơi phức tạp, dùng để lấy topicName

                // Gọi hàm trong MainActivity để chuyển màn hình
                // Truyền cả tên chủ đề, toàn bộ danh sách, và vị trí click
                ((TruyenCuoiActivity) context).gotoM003Screen(topicName, listStory, clickedPosition);
            });
        }
    }
}