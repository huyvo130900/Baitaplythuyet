package com.example.lab3;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

// Đây là Activity MỚI chỉ dành cho Bài 1
public class TruyenCuoiActivity extends AppCompatActivity {
    private String topicName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // SỬA DÒNG NÀY:
        // Đổi R.layout.activity_main thành R.layout.activity_truyen_cuoi
        setContentView(R.layout.activity_truyen_cuoi);

        showFrg(new M000SplashFrg());
    }

    private void showFrg(Fragment frg) {
        // ID "ln_main" bây giờ nằm trong "activity_truyen_cuoi.xml"
        getSupportFragmentManager().beginTransaction().replace(R.id.ln_main, frg,
                null).commit();
    }

    public void gotoM001Screen() {
        showFrg(new M001TopicFrg());
    }

    public void gotoM002Screen(String topicName) {
        showFrg(new M002StoryListFrg(topicName));
    }

    public void backToM001Screen() {
        gotoM001Screen();
    }

    public void gotoM003Screen(String topicName, ArrayList<StoryEntity> listStory, int clickedPosition) {
        showFrg(new M003StoryDetailFrg(topicName, listStory, clickedPosition));
    }
}