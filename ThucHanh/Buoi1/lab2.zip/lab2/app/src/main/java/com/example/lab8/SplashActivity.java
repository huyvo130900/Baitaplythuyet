package com.example.lab8; // Thay bằng tên package của bạn

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.view.View; // Import thư viện View
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.Random;

public class SplashActivity extends AppCompatActivity {

    LinearLayout splashLayout;
    ImageView splashIcon;
    View loadingOverlay; // 1. Khai báo View cho lớp loading

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m001_act_splash);

        // Ánh xạ các View
        splashLayout = findViewById(R.id.splashLayout);
        splashIcon = findViewById(R.id.splashIcon);
        loadingOverlay = findViewById(R.id.loadingOverlay); // 2. Ánh xạ loadingOverlay

        // --- Giữ nguyên code Bài 1 (màu ngẫu nhiên + icon penguin) ---
        Random random = new Random();
        int[] colorList = {
                android.R.color.holo_blue_light,
                android.R.color.holo_green_light,
                android.R.color.holo_red_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_purple,
                android.R.color.black,
                android.R.color.holo_blue_dark,
                android.R.color.holo_green_dark
        };
        int randomColorIndex = random.nextInt(colorList.length);
        splashIcon.setImageResource(R.drawable.penguin);
        splashLayout.setBackgroundColor(ContextCompat.getColor(this, colorList[randomColorIndex]));
        // --- Hết code Bài 1 ---


        // 3. (CODE MỚI) Nhận tín hiệu từ MainActivity
        // Lấy "gói hàng" (extra) tên là "SHOW_LOADING"
        // Nếu không tìm thấy, mặc định là false (là Bài 1)
        boolean showLoading = getIntent().getBooleanExtra("SHOW_LOADING", false);

        // 4. Quyết định ẨN hay HIỆN lớp loading
        if (showLoading) {
            // Nếu là Bài 2
            loadingOverlay.setVisibility(View.VISIBLE); // HIỆN
        } else {
            // Nếu là Bài 1
            loadingOverlay.setVisibility(View.GONE); // ẨN
        }
    }
}