package com.example.lab8; // Thay bằng tên package của bạn

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager; // --- Thêm import này ---
import android.view.View;
import android.widget.TableRow;
import android.widget.Toast;

public class ProfileActivity extends AppCompatActivity {

    // Khai báo hằng số để nhận diện yêu cầu xin quyền
    private static final int REQUEST_CALL_PHONE = 1;
    private static final int REQUEST_SEND_SMS = 2; // --- Thêm hằng số này ---

    TableRow rowPhone1;
    TableRow rowEmail;
    TableRow rowSms;

    private String phoneNumber1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m001_act_profile);

        // Ánh xạ các View
        rowPhone1 = findViewById(R.id.row_phone_1);
        rowEmail = findViewById(R.id.row_email);
        rowSms = findViewById(R.id.row_sms); // Đảm bảo ID này có trong XML

        // Lấy số điện thoại và email từ strings.xml
        phoneNumber1 = getString(R.string.txt_phone1);
        final String emailAddress = getString(R.string.txt_email);

        // Xử lý sự kiện click vào hàng số điện thoại
        rowPhone1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePhoneCall();
            }
        });

        // Xử lý sự kiện click vào hàng email
        rowEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                composeEmail(emailAddress);
            }
        });

        // --- ĐÃ THAY ĐỔI ---
        // Xử lý sự kiện click vào hàng SMS
        if (rowSms != null) {
            rowSms.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Gọi hàm tự động gửi SMS (thay vì mở app)
                    sendSms();
                }
            });
        }
    }

    /**
     * Thực hiện cuộc gọi (ACTION_CALL)
     */
    private void makePhoneCall() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.CALL_PHONE},
                    REQUEST_CALL_PHONE);
        } else {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + phoneNumber1));
            startActivity(intent);
        }
    }

    /**
     * Mở ứng dụng Email
     */
    private void composeEmail(String emailAddress) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:" + emailAddress));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    /**
     * --- HÀM MỚI ---
     * Tự động gửi SMS và hiển thị Toast "SMS sent"
     * Yêu cầu kiểm tra và xin quyền SEND_SMS lúc chạy
     */
    private void sendSms() {
        // Kiểm tra xem quyền SEND_SMS đã được cấp chưa
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Nếu chưa, yêu cầu người dùng cấp quyền
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.SEND_SMS},
                    REQUEST_SEND_SMS);
        } else {
            // Nếu đã có quyền, thực hiện gửi tin nhắn
            try {
                SmsManager smsManager = SmsManager.getDefault();
                // Gửi tin nhắn
                smsManager.sendTextMessage(phoneNumber1, null, "Hello from ProfileActivity!", null, null);
                // Hiển thị thông báo thành công
                Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                // Hiển thị thông báo nếu có lỗi
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }


    /**
     * --- ĐÃ CẬP NHẬT ---
     * Hàm này được gọi sau khi người dùng trả lời hộp thoại xin quyền
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CALL_PHONE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall();
            } else {
                Toast.makeText(this, "Call permission denied", Toast.LENGTH_SHORT).show();
            }
        }
        // Thêm xử lý cho REQUEST_SEND_SMS
        else if (requestCode == REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Nếu người dùng "Allow", gọi lại hàm sendSms() để gửi
                sendSms();
            } else {
                // Nếu người dùng "Deny", thông báo cho họ
                Toast.makeText(this, "Send SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

