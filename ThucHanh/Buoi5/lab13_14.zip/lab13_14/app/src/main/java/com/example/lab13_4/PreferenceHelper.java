package com.example.lab13_4;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceHelper {
    private static final String PREF_NAME = "LoginPrefs";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_REMEMBER = "remember";
    
    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    
    public PreferenceHelper(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }
    
    public void saveLoginInfo(String email, String password, boolean remember) {
        editor.putString(KEY_EMAIL, email);
        editor.putString(KEY_PASSWORD, password);
        editor.putBoolean(KEY_REMEMBER, remember);
        editor.apply();
    }
    
    public String getSavedEmail() {
        return prefs.getString(KEY_EMAIL, "");
    }
    
    public String getSavedPassword() {
        return prefs.getString(KEY_PASSWORD, "");
    }
    
    public boolean isRememberMe() {
        return prefs.getBoolean(KEY_REMEMBER, false);
    }
    
    public void clearLoginInfo() {
        editor.clear();
        editor.apply();
    }
}
