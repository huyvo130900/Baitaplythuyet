package com.example.lab13_4;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class M000LoginFragment extends Fragment implements View.OnClickListener {
    private EditText edtEmail, edtPass;
    private CheckBox cbRemember;
    private Context mContext;
    private DatabaseHelper dbHelper;
    private PreferenceHelper prefHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.m000_frg_login, container, false);
        initView(rootView);
        loadSavedLogin();
        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
        dbHelper = new DatabaseHelper(context);
        prefHelper = new PreferenceHelper(context);
    }

    private void initView(View v) {
        edtEmail = v.findViewById(R.id.edt_email);
        edtPass = v.findViewById(R.id.edt_pass);
        cbRemember = v.findViewById(R.id.cb_remember);
        
        v.findViewById(R.id.tv_login).setOnClickListener(this);
        v.findViewById(R.id.tv_register).setOnClickListener(this);
    }

    private void loadSavedLogin() {
        if (prefHelper.isRememberMe()) {
            edtEmail.setText(prefHelper.getSavedEmail());
            edtPass.setText(prefHelper.getSavedPassword());
            cbRemember.setChecked(true);
        }
    }

    @Override
    public void onClick(View v) {
        v.startAnimation(AnimationUtils.loadAnimation(mContext,
                androidx.appcompat.R.anim.abc_fade_in));
        
        if (v.getId() == R.id.tv_login) {
            login(edtEmail.getText().toString(), edtPass.getText().toString());
        } else if (v.getId() == R.id.tv_register) {
            gotoRegisterScreen();
        }
    }

    private void gotoRegisterScreen() {
        ((MainActivity) mContext).gotoRegisterScreen();
    }

    private void login(String mail, String pass) {
        if (mail.isEmpty() || pass.isEmpty()) {
            Toast.makeText(mContext, "Empty value", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean loginSuccess = dbHelper.loginUser(mail, pass);
        
        if (loginSuccess) {
            if (cbRemember.isChecked()) {
                prefHelper.saveLoginInfo(mail, pass, true);
            } else {
                prefHelper.clearLoginInfo();
            }
            
            Toast.makeText(mContext, "Login account successfully!", Toast.LENGTH_SHORT).show();
            ((MainActivity) mContext).gotoHomeScreen();
        } else {
            Toast.makeText(mContext, "Email or password is incorrect!", Toast.LENGTH_SHORT).show();
        }
    }
}
