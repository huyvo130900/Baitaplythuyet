package com.example.lab13_4;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.util.List;

public class M002HomeFragment extends Fragment implements View.OnClickListener {
    private TextView tvUserEmail;
    private Context mContext;
    private DatabaseHelper dbHelper;
    private PreferenceHelper prefHelper;
    private AccountManager accountManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.m002_frg_home, container, false);
        initView(rootView);
        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
        dbHelper = new DatabaseHelper(context);
        prefHelper = new PreferenceHelper(context);
        accountManager = new AccountManager(context);
    }

    private void initView(View v) {
        tvUserEmail = v.findViewById(R.id.tv_user_email);
        
        String loggedInEmail = dbHelper.getLoggedInUser();
        if (loggedInEmail != null) {
            tvUserEmail.setText(loggedInEmail);
        }
        
        v.findViewById(R.id.tv_view_accounts).setOnClickListener(this);
        v.findViewById(R.id.tv_logout).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        v.startAnimation(AnimationUtils.loadAnimation(mContext,
                androidx.appcompat.R.anim.abc_fade_in));
        
        if (v.getId() == R.id.tv_logout) {
            logout();
        } else if (v.getId() == R.id.tv_view_accounts) {
            showAccountsList();
        }
    }

    private void showAccountsList() {
        String accountsInfo = accountManager.exportAccountsToString();
        
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setTitle("Danh sách tài khoản");
        builder.setMessage(accountsInfo);
        builder.setPositiveButton("OK", null);
        builder.setNegativeButton("Copy", (dialog, which) -> {
            android.content.ClipboardManager clipboard = 
                (android.content.ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
            android.content.ClipData clip = android.content.ClipData.newPlainText("Accounts", accountsInfo);
            clipboard.setPrimaryClip(clip);
            Toast.makeText(mContext, "Đã copy vào clipboard!", Toast.LENGTH_SHORT).show();
        });
        
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void logout() {
        String loggedInEmail = dbHelper.getLoggedInUser();
        
        if (loggedInEmail != null) {
            dbHelper.logoutUser(loggedInEmail);
            prefHelper.clearLoginInfo();
            Toast.makeText(mContext, "Logged out successfully!", Toast.LENGTH_SHORT).show();
            ((MainActivity) mContext).gotoLoginScreen();
        }
    }
}
