package com.example.lab13_4;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AccountManager {
    private DatabaseHelper dbHelper;
    private Context context;

    public AccountManager(Context context) {
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
    }

    public List<Account> getAllAccounts() {
        List<Account> accounts = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        
        Cursor cursor = db.query("users", 
            new String[]{"id", "email", "password", "is_logged_in"},
            null, null, null, null, "id ASC");

        if (cursor.moveToFirst()) {
            do {
                Account account = new Account();
                account.id = cursor.getInt(0);
                account.email = cursor.getString(1);
                account.password = cursor.getString(2);
                account.isLoggedIn = cursor.getInt(3) == 1;
                accounts.add(account);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return accounts;
    }

    public String exportAccountsToString() {
        List<Account> accounts = getAllAccounts();
        StringBuilder sb = new StringBuilder();
        
        sb.append("=====================================\n");
        sb.append("DANH SÁCH TÀI KHOẢN TRONG DATABASE\n");
        sb.append("=====================================\n\n");
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
        sb.append("Thời gian xuất: ").append(sdf.format(new Date())).append("\n");
        sb.append("Tổng số tài khoản: ").append(accounts.size()).append("\n\n");
        
        sb.append("-------------------------------------\n");
        sb.append("CHI TIẾT TÀI KHOẢN\n");
        sb.append("-------------------------------------\n\n");
        
        if (accounts.isEmpty()) {
            sb.append("Chưa có tài khoản nào được đăng ký.\n");
        } else {
            for (int i = 0; i < accounts.size(); i++) {
                Account acc = accounts.get(i);
                sb.append(i + 1).append(". Tài khoản #").append(acc.id).append("\n");
                sb.append("   Email: ").append(acc.email).append("\n");
                sb.append("   Password: ").append(acc.password).append("\n");
                sb.append("   Trạng thái: ").append(acc.isLoggedIn ? "Đang đăng nhập" : "Đã đăng xuất").append("\n");
                sb.append("\n");
            }
        }
        
        sb.append("=====================================\n");
        sb.append("LƯU Ý BẢO MẬT\n");
        sb.append("=====================================\n");
        sb.append("⚠️ File này chứa thông tin nhạy cảm!\n");
        sb.append("- Không chia sẻ file này với người khác\n");
        sb.append("- Xóa file sau khi sử dụng\n");
        sb.append("- Trong ứng dụng thực tế, không nên\n");
        sb.append("  lưu password dạng plain text\n");
        
        return sb.toString();
    }

    public boolean saveAccountsToFile() {
        try {
            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File file = new File(downloadsDir, "accounts_list.txt");
            
            FileWriter writer = new FileWriter(file);
            writer.write(exportAccountsToString());
            writer.close();
            
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static class Account {
        public int id;
        public String email;
        public String password;
        public boolean isLoggedIn;
    }
}
