package com.example.lab13_4;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    public static final String SAVE_PREF = "save_pref";
    
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        
        dbHelper = new DatabaseHelper(this);
        
        if (dbHelper.isUserLoggedIn()) {
            gotoHomeScreen();
        } else {
            gotoLoginScreen();
        }
    }

    public void gotoRegisterScreen() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, new M001RegisterFragment())
                .commit();
    }

    public void gotoLoginScreen() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, new M000LoginFragment())
                .commit();
    }
    
    public void gotoHomeScreen() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, new M002HomeFragment())
                .commit();
    }
}
