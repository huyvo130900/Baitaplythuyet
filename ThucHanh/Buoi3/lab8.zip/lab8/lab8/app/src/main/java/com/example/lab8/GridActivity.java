package com.example.lab8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;

import java.util.ArrayList;

public class GridActivity extends AppCompatActivity {

    GridView grid;
    ArrayList<Contributor> arr;
    ContributorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        grid = findViewById(R.id.gridContributors);

        arr = new ArrayList<>();
        arr.add(new Contributor(R.drawable.avatar1, "Măng", "195,500"));
        arr.add(new Contributor(R.drawable.avatar2, "Hamburger", "310,200"));
        arr.add(new Contributor(R.drawable.avatar3, "Pizza", "89,900"));
        arr.add(new Contributor(R.drawable.avatar4, "Bánh mì thịt", "120,000"));
        arr.add(new Contributor(R.drawable.avatar5, "Cá hồi", "450,750"));
        arr.add(new Contributor(R.drawable.avatar6, "bánh giò", "75,000"));

        adapter = new ContributorAdapter(this, arr);
        grid.setAdapter(adapter);
    }
}
