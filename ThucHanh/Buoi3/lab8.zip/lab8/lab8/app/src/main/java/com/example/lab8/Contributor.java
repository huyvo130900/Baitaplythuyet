package com.example.lab8;

public class Contributor {
    public int avatar;
    public String name;
    public String score;

    public Contributor(int avatar, String name, String score) {
        this.avatar = avatar;
        this.name = name;
        this.score = score;
    }
}
