package com.example.lab7;

import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.graphics.Color;

import androidx.appcompat.app.AppCompatActivity;

public class Bai3Activity extends AppCompatActivity {


    SeekBar seekR, seekG, seekB;
    View viewColor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai3);


        seekR = findViewById(R.id.seekR);
        seekG = findViewById(R.id.seekG);
        seekB = findViewById(R.id.seekB);
        viewColor = findViewById(R.id.viewColor);


        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                updateColor();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        };


        seekR.setOnSeekBarChangeListener(listener);
        seekG.setOnSeekBarChangeListener(listener);
        seekB.setOnSeekBarChangeListener(listener);
    }


    private void updateColor() {
        int r = seekR.getProgress();
        int g = seekG.getProgress();
        int b = seekB.getProgress();


        viewColor.setBackgroundColor(Color.rgb(r, g, b));
    }
}
