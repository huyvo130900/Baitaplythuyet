package com.example.lab7;

import android.app.Dialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Bai2Activity extends AppCompatActivity {

    Animation animBounce, animFade, animRotate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);

        // Load animation
        animBounce = AnimationUtils.loadAnimation(this, R.anim.btn_bounce);
        animFade   = AnimationUtils.loadAnimation(this, R.anim.btn_fade_color);
        animRotate = AnimationUtils.loadAnimation(this, R.anim.btn_rotate);

        // Gán animation cho các nút
        setAction(R.id.btnColorSelector, animBounce);
        setAction(R.id.btnDisabled, animFade);
        setAction(R.id.btnTextSelector, animFade);
        setAction(R.id.btnRoundShape, animBounce);
        setAction(R.id.btnGradient, animRotate);
        setAction(R.id.btnSelectorShape, animBounce);

        setAction(R.id.btnEmoji1, animRotate);
        setAction(R.id.btnEmoji2, animBounce);
        setAction(R.id.btnEmoji3, animRotate);

        // TOAST
        findViewById(R.id.btnToast).setOnClickListener(v -> showCustomToast());

        // DIALOG
        findViewById(R.id.btnDialog).setOnClickListener(v -> showCustomDialog());
    }


    private void setAction(int id, Animation anim) {
        View v = findViewById(id);
        if (v == null) return;

        v.setOnClickListener(x -> {
            v.startAnimation(anim);
        });
    }

    // CUSTOM TOAST
    private void showCustomToast() {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast, null);

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM, 0, 200);
        toast.setView(layout);
        toast.show();
    }

    // CUSTOM DIALOG
    private void showCustomDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.custom_dialog);
        dialog.setCancelable(true);

        EditText edtUser = dialog.findViewById(R.id.edtUser);
        EditText edtPass = dialog.findViewById(R.id.edtPass);
        Button btnOK = dialog.findViewById(R.id.btnOK);
        Button btnCancel = dialog.findViewById(R.id.btnCancel);

        btnOK.setOnClickListener(v -> {
            Toast.makeText(this,
                    "User: " + edtUser.getText() + "\nPass: " + edtPass.getText(),
                    Toast.LENGTH_LONG).show();
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }
}
