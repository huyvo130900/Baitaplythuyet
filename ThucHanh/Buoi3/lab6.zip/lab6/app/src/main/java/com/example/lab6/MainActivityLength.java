package com.example.lab6;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivityLength extends AppCompatActivity {

    Spinner spUnitFrom, spUnitTo;
    EditText edtValue;
    TextView tvOutput;

    String[] units = {"m", "cm", "inch", "foot"};

    double[][] lenRate = {
            {1.0,     100.0,   39.37, 3.28},
            {0.01,    1.0,     0.3937, 0.0328},
            {0.0254,  2.54,    1.0,    0.083333},
            {0.3048,  30.48,   12.0,   1.0}
    };

    int from = 0, to = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);

        spUnitFrom = findViewById(R.id.spUnitFrom);
        spUnitTo = findViewById(R.id.spUnitTo);
        edtValue = findViewById(R.id.edtValue);
        tvOutput = findViewById(R.id.tvOutput);

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spUnitFrom.setAdapter(adapter);
        spUnitTo.setAdapter(adapter);

        spUnitFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                from = position;
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        spUnitTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                to = position;
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }


    public void convert(View v) {
        String s = edtValue.getText().toString().trim();
        if (s.isEmpty()) {
            tvOutput.setText("Chưa nhập giá trị!");
            return;
        }

        double input;
        try {
            input = Double.parseDouble(s);
        } catch (NumberFormatException ex) {
            tvOutput.setText("Giá trị không hợp lệ!");
            return;
        }

        double result = input * lenRate[from][to];
        tvOutput.setText(String.format("%s %s = %.6f %s", s, units[from], result, units[to]));
    }
}
