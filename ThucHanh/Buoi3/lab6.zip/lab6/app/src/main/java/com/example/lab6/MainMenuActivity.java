package com.example.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainMenuActivity extends AppCompatActivity {

    Button btnCurrency, btnLength;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        btnCurrency = findViewById(R.id.btnCurrency);
        btnLength = findViewById(R.id.btnLength);

        btnCurrency.setOnClickListener(v -> {
            Intent i = new Intent(MainMenuActivity.this, MainActivity.class);
            startActivity(i);
        });

        btnLength.setOnClickListener(v -> {
            Intent i = new Intent(MainMenuActivity.this, MainActivityLength.class);
            startActivity(i);
        });
    }
}
