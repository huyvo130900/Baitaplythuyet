package com.example.lab6;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Spinner spFrom, spTo;
    EditText edtMoney;
    TextView tvResult;
    Button btnConvert;


    String[] moneyNames = {
            "USD", "EUR", "GBP", "AUD", "CAD",
            "ZAR", "NZD", "INR", "JPY", "VND"
    };


    double[][] rate = {
            //USD   EUR   GBP   AUD   CAD   ZAR   NZD   INR   JPY     VND
            {1,    0.90, 0.78, 1.48, 1.36, 18.0, 1.62, 83.0, 151.0,  25000}, // USD
            {1.1,  1,    0.86, 1.65, 1.51, 20.0, 1.80, 92.0, 168.0,  27500}, // EUR
            {1.28, 1.16, 1,    1.90, 1.73, 22.0, 2.00, 105.0, 190.0, 31000}, // GBP
            {0.68, 0.60, 0.52, 1,    0.91, 11.5, 1.05, 55.0, 100.0, 16000}, // AUD
            {0.73, 0.66, 0.58, 1.10, 1,    12.0, 1.15, 60.0, 108.0, 17500}, // CAD
            {0.055,0.050,0.045,0.087,0.083,1,    0.095,5.0,  9.0,  1500},  // ZAR
            {0.62, 0.55, 0.50, 0.95, 0.87, 10.5, 1,    52.0,  95.0, 15500}, // NZD
            {0.012,0.011,0.0095,0.018,0.016,0.20,0.019,1,   1.8,  300},   // INR
            {0.0066,0.0060,0.0052,0.010,0.0092,0.11,0.0105,0.55,1,  170},  // JPY
            {0.000040,0.000036,0.000032,0.000062,0.000057,0.00066,0.000064,0.0033,0.0059,1} // VND
    };

    int fromPos = 0, toPos = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spFrom = findViewById(R.id.spFrom);
        spTo = findViewById(R.id.spTo);
        edtMoney = findViewById(R.id.edtMoney);
        tvResult = findViewById(R.id.tvResult);
        btnConvert = findViewById(R.id.btnConvert);

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, moneyNames);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spFrom.setAdapter(adapter);
        spTo.setAdapter(adapter);

        spFrom.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                fromPos = i;
            }
            @Override public void onNothingSelected(AdapterView<?> adapterView) { }
        });

        spTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                toPos = i;
            }
            @Override public void onNothingSelected(AdapterView<?> adapterView) { }
        });

        btnConvert.setOnClickListener(v -> {
            String val = edtMoney.getText().toString().trim();
            if (val.isEmpty()) {
                tvResult.setText("Vui lòng nhập số tiền!");
                return;
            }
            double input = Double.parseDouble(val);
            double output = input * rate[fromPos][toPos];
            tvResult.setText("Kết quả: " + output);
        });
    }
}
