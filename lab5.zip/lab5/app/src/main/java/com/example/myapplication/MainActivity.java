package com.example.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private TextView tvContent;
    private BroadcastReceiver broadcastReceiver;
    private IntentFilter filter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvContent = findViewById(R.id.tv_content);
        initBroadcastReceiver();

        // YÊU CẦU QUYỀN RECEIVE_SMS (cho Android 6.0+)
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECEIVE_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.RECEIVE_SMS}, 100);
        } else {
            // Nếu đã có quyền, hiển thị thông báo
            Toast.makeText(this, "Bài 1: Nhận tin nhắn\nBài 2: Theo dõi sạc pin", Toast.LENGTH_LONG).show();
        }
    }

    // Xử lý kết quả yêu cầu quyền
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Đã cấp quyền nhận tin nhắn", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Cần cấp quyền để nhận tin nhắn", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Khai báo biến (theo PDF)
    private void initBroadcastReceiver() {
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                processReceive(context, intent);
            }
        };

        filter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        // THÊM DÒNG NÀY: Đặt độ ưu tiên cao để nhận tin nhắn
        filter.setPriority(IntentFilter.SYSTEM_HIGH_PRIORITY);
    }

    // Xây dựng hàm xử lý khi tin nhắn đến (theo đúng PDF) - ĐÃ SỬA LỖI
    public void processReceive(Context context, Intent intent) {
        // Hiển thị Toast thông báo
        Toast.makeText(context, getString(R.string.you_have_a_new_message),
                Toast.LENGTH_LONG).show();

        // SỬA LỖI: Sử dụng biến tvContent đã khai báo, không tìm lại bằng findViewById
        // TextView tvContent = (TextView) findViewById(R.id.tv_content);

        // Use "pdus" as key to get message
        final String SMS_EXTRA = "pdus";
        Bundle bundle = intent.getExtras();

        // KIỂM TRA NULL để tránh crash
        if (bundle == null) {
            return;
        }

        // Get array of messages which were received at the same time
        Object[] messages = (Object[]) bundle.get(SMS_EXTRA);

        // KIỂM TRA NULL để tránh crash
        if (messages == null) {
            return;
        }

        StringBuilder sms = new StringBuilder(); // Sử dụng StringBuilder để tối ưu

        for (int i = 0; i < messages.length; i++) {
            SmsMessage smsMsg;

            // Xử lý theo version Android (theo PDF) - ĐÃ SỬA
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { // Sử dụng Build.VERSION_CODES.M thay vì 23
                String format = bundle.getString("format"); // Lấy format từ bundle
                smsMsg = SmsMessage.createFromPdu((byte[]) messages[i], format);
            } else {
                smsMsg = SmsMessage.createFromPdu((byte[]) messages[i]);
            }

            // KIỂM TRA NULL để tránh crash
            if (smsMsg != null) {
                // Get message body
                String msgBody = smsMsg.getMessageBody();

                // Get source address of message
                String address = smsMsg.getDisplayOriginatingAddress();
                sms.append("SĐT: ").append(address)
                        .append("\nNội dung: ").append(msgBody).append("\n\n");
            }
        }

        // Show messages in textView
        tvContent.setText(sms.toString());
    }

    // Tự động đăng ký và hủy đăng ký BroadcastReceiver khi Resume, Stop Activity
    @Override
    protected void onResume() {
        super.onResume();
        // Đăng ký BroadcastReceiver
        try {
            registerReceiver(broadcastReceiver, filter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Hủy đăng ký BroadcastReceiver
        try {
            unregisterReceiver(broadcastReceiver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Hủy đăng ký để tránh memory leak
        if (broadcastReceiver != null) {
            try {
                unregisterReceiver(broadcastReceiver);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}