package com.example.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import java.util.ArrayList;

public class SmsReceiver extends BroadcastReceiver {
    public static final String SMS_FORWARD_BROADCAST_RECEIVER = "sms_forward_broadcast_receiver";
    public static final String SMS_MESSAGE_ADDRESS_KEY = "sms_messages_key";

    @Override
    public void onReceive(Context context, Intent intent) {
        String queryString = "Are you OK?".toLowerCase();
        Log.d("SmsReceiver", "Nhận được tin nhắn, kiểm tra từ khóa: " + queryString);

        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            Object[] pdus = (Object[]) bundle.get("pdus");
            if (pdus == null) return;

            SmsMessage[] messages = new SmsMessage[pdus.length];
            for (int i = 0; i < pdus.length; i++) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    String format = bundle.getString("format");
                    messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i], format);
                } else {
                    messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                }
            }

            // Tạo danh sách số điện thoại chứa từ khóa
            ArrayList<String> addresses = new ArrayList<>();
            for (SmsMessage message : messages) {
                if (message != null && message.getMessageBody() != null) {
                    String messageBody = message.getMessageBody().toLowerCase();
                    if (messageBody.contains(queryString)) {
                        String address = message.getOriginatingAddress();
                        addresses.add(address);
                        Log.d("SmsReceiver", "Tìm thấy từ khóa từ: " + address);
                    }
                }
            }

            if (addresses.size() > 0) {
                if (!EmergencyActivity.isRunning) {
                    // TH2: App đang tắt - Start lại MainActivity
                    Log.d("SmsReceiver", "App đang tắt, khởi động lại...");
                    Intent iMain = new Intent(context, EmergencyActivity.class);
                    iMain.putStringArrayListExtra(SMS_MESSAGE_ADDRESS_KEY, addresses);
                    iMain.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(iMain);
                } else {
                    // TH1: App đang chạy - Gửi broadcast
                    Log.d("SmsReceiver", "App đang chạy, gửi broadcast...");
                    Intent iForward = new Intent(SMS_FORWARD_BROADCAST_RECEIVER);
                    iForward.putStringArrayListExtra(SMS_MESSAGE_ADDRESS_KEY, addresses);
                    context.sendBroadcast(iForward);
                }
            }
        }
    }
}