package com.example.lab8; // Thay bằng tên package của bạn

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    // 1. Khai báo thêm btnBai3
    Button btnBai1, btnBai2, btnBai3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 2. Ánh xạ thêm btnBai3
        btnBai1 = findViewById(R.id.btnBai1);
        btnBai2 = findViewById(R.id.btnBai2);
        btnBai3 = findViewById(R.id.btnBai3); // (Dòng mới)

        // --- Xử lý click Bài 1 (Giữ nguyên) ---
        btnBai1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDisplay(false);
            }
        });

        // --- Xử lý click Bài 2 (Giữ nguyên) ---
        btnBai2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDisplay(true);
            }
        });

        // 3. (CODE MỚI) Xử lý click Bài 3
        btnBai3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mở ProfileActivity (Bài 3)
                // Bài 3 là một Activity riêng nên không cần gửi extra
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });
    }

    // Hàm này chỉ dùng cho Bài 1 và 2 (Giữ nguyên)
    private void openDisplay(boolean showLoading) {
        Intent intent = new Intent(MainActivity.this, SplashActivity.class);
        intent.putExtra("SHOW_LOADING", showLoading);
        startActivity(intent);
    }
}