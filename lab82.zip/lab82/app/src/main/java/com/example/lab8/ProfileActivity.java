package com.example.lab8; // Thay bằng tên package của bạn

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TableRow;

public class ProfileActivity extends AppCompatActivity {

    TableRow rowPhone1;
    TableRow rowEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Liên kết với file layout
        setContentView(R.layout.m001_act_profile);

        // Ánh xạ các View đã đặt ID trong file XML
        rowPhone1 = findViewById(R.id.row_phone_1);
        rowEmail = findViewById(R.id.row_email);

        // Xử lý sự kiện click vào hàng số điện thoại
        rowPhone1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lấy số điện thoại từ file strings.xml
                String phoneNumber = getString(R.string.txt_phone1);
                // Gọi hàm thực hiện cuộc gọi
                dialPhoneNumber(phoneNumber);
            }
        });

        // Xử lý sự kiện click vào hàng email
        rowEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lấy email từ file strings.xml
                String emailAddress = getString(R.string.txt_email);
                // Gọi hàm mở ứng dụng email
                composeEmail(emailAddress);
            }
        });
    }

    /**
     * Mở màn hình quay số với số điện thoại đã điền sẵn
     * Chúng ta dùng ACTION_DIAL (mở màn hình quay số)
     * thay vì ACTION_CALL (gọi ngay) vì ACTION_CALL yêu cầu xin quyền
     * rất phức tạp (android.permission.CALL_PHONE).
     */
    private void dialPhoneNumber(String phoneNumber) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + phoneNumber));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    /**
     * Mở ứng dụng Email với địa chỉ đã điền sẵn
     */
    private void composeEmail(String emailAddress) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:" + emailAddress)); // Chỉ mở app email
        // intent.putExtra(Intent.EXTRA_EMAIL, new String[]{emailAddress}); // Điền sẵn email
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}